/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */

// Mark Eilers
// 7-1 Project
// CS-350-R3340
// February 8, 2024

// Include the necessary libraries
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

// Include the driver header files
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Timer.h>

// Driver configuration
#include "ti_drivers_config.h"

// Init buttons before callback
int leftButton = 0;         // Decrement with the left button
int rightButton = 0;        // Increment with the right button

/*
 * =========== pgioButtonFxn0 ===============
 * Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 * Note: GPIO interrupts are cleared prior to invoking callbacks.
 */

void gpioButtonFxn0(uint_least8_t index) {

    // Left button function
    leftButton = 1;
}
/*
 * =========== gpioButtonFxn1 ===============
 * Callback funtion for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *
 * Note: GPIO interrupts are cleared prior to invoking callbacks.
 */

void gpioButtonFxn1(unit_least8_t index) {

    // Right button function
    rightButton = 1;
}

/*
 * ============ UART code begin ===============
 */

// Define the display for the UART code.
#define DISPLAY(x) UART_write(uart, &output, x);

// UART Global Variables
char output [64];
int bytesToSend;

// Driver Handles - Global variables
UART_Handle uart;
void initUART(void) {
    UART_Params uartParams;

    // Init the driver
    UART_init();

    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);

    // If statement for if the uart is NULL.
    if (uart == NULL) {

        // UART_open() has failed.
        while (1);
    }
}

/*
 * =========== I2C Code =============
 */

// Create the I2C global variables.
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
}

sensors [3] = {
               {0x48, 0x0000, "11X"},
               {0x49, 0x0000, "116"},
               {0x41, 0x0001, "006"}
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

// Global variables for the driver handles.
I2C_Handle i2c;

// Call the initUART() before calling this funtion.
void initI2c(void) {
    int8_t i, found;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));

    // Initializing the driver
    I2C_init();

    // Configure the driver.
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);

    // If statement for when i2c is null display error.
    if (i2c == NULL) {
        DISPLAY(snprintf(output, 64, "Failed\n\r"));
        while (1);
    }

    // Print statement for when passed
    DISPLAY(snprintf(output, 32, "Passed\n\r"));

    // Common I2C transaction setup
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;

    // For statement when i = 0 and less than 3 increment +1
    for (i = 0; i < 3; ++i) {
        i2cTransaction.targetAddress = sensors [i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));

        // If statement if the I2C_transfer is found.
        if (I2C_transfer(i2c, &i2cTransaction)) {
            DISPLAY(snprintf(output, 64, "Found\n\r"));
            found = true;
            break;
        }

        // Display not found if not found
        DISPLAY(snprintf(output, 64, "No\n\r"));
    };

    // if else statement if found.
    if (found) {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2sTransaction.targetAddress));
    }

    else {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found\n\r"));
    }
}

int16_t readTemp(void) {
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;

    // If statement to get degrees c
    if (I2C_transfer(i2c, &i2cTransaction)) {

        // Extract degrees C from the received data.
        temperaute = (rxBuffer[0] << 8 | (rxBuffer [1]));
        temperature *= 0.0078125;

        /*
         * If the MSB is set 'i', then we have 2's complement
         * negative values which needs to be sign extended
         */

        if (rxBuffer[0] & 0x80) {
            temperature |= 0xF000;
        }
    }

    else {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r", i2cTransaction.status));

        DISPLAY(snprintf(output, 64, "Power cycle the board by unplugging and plugging the board back in.\n\r"));
    }

    return temperature;
}

/*
 * ========= Timer code ============
 */

// Global Variables for the Driver Handle
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;
void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    TimerFlag = 1
}

void initTimer(void) {
    Timer_Params params;

    // Initialize the driver
    Timer_init();

    // Configure the driver
    Timer_Params_init(&params);
    params.period = 1000000;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.periodUnits = Timer_PERIOD_US;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    // If statement for if the timer is Null
    if (timer0 == NULL) {

        // Failed to initialize timer
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {

        // Failed to start the timer
        while (1) {}
    }
}

/*
 * =========== mainThread ============
 */

void *mainThread(void *arg0) {

    // Call the driver initialize function
    GPIO_init();

    // Configure the red light
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    // Configure the button pin
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    // Turn on the user LED
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    // Install button callback
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    // Enable interrupts
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    // If more than on input pin is available for your device, interrupts will be enabled on CONFIG_BUTTON_1

    if (CONFIG_GPIO)BUTTON_0 != CONFIG_GPIO_BUTTON_1) {

        // Set the Configure Button1
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        // Install button callback
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);

        // Enable interrupts
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

/*
 * ========== Main Code ==========
 */

    // Call driver init functions
    initUART();
    initI2C();
    initTimer();

    // Initialize the variables

    // Elapse times for button
    unsigned long buttonCheckTime = 0;

    // Elapse time for temp
    unsigned long tempCheckTime = 0;

    // Elapsed time for display
    unsigned long displayCheckTime = 0;

    // Constant button period (200ms)
    const unsigned long buttonCheckPeriod = 200;

    // Constant temp period (500ms)
    const unsigned long tempCheckPeriod = 500;

    // Constant display period (1000ms)
    const unsigned long displayCheckPeriod = 1000;

    // Constant timer period/GCD (100ms)
    const unsigned long timerPeriod = 100;

    //setpoint (default thermostat value)
    int setpoint = 25;

    // heat (0 is off, 1 is on)
    int heat = 0;

    // Seconds
    int seconds = 0;

    // Temperature (temperature will equal ambient board temperature)
    int temperature = 0;

/*
 * ======= Main while loop ============
 */

    while (1) {

        // read the temperature changes on the board.
        readTemp();

        // Every 200ms, check the button presses
        if (buttonCHeckTime >= buttonCheckPeriod) {

            // if the right button equals 1
            if (rightButton == 1) {

                // Increment the thermostat
                setpoint += 1;

                // Reset the button
                rightButton = 0;
            }

            if (leftButton == 1){

                // Decrement the thermostat
                setpoint -= 1;

                // Reset the button
                leftButton == 0;
            }
        }

        // Every 500ms check temperature and update
        if (tempCheckTime >= tempCheckPeriod) {

            // set the temperature to read temp
            temperature = readTemp();

            // Temp is lower than the thermostat setting
            if (temperature < setpoint) {

                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                heat = 1; // Turn on heat
            }

            // Temp is higher than the thermostat setting
            else {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                heat = 0; // Turn off heat
            }
        }

        // Every 1000ms output to UART to display temperature
        if (displayCheckTime >= displayCheckPeriod) {
            DISPLAY(snprintf(output, 64, "<%02d, %02d, %d, %04d>\n\r", temperature, setpoint, heat, seconds));

            // Increment the seconds every 1000ms
            ++seconds;
        }

        while (!TimerFlag) {} // Wait for timer period
        TimerFlag= 0; // Lower flag raise by timer
        buttonCheckTime += timerPeriod;  // Increment buttonCheckTime by 100ms
        tempCheckTime += timerPeriod;  // Increment tempChekTime by 100ms
        displayCheckTime += timperPeriod;  // Increment displayCheckTime by 100ms
    }
}
