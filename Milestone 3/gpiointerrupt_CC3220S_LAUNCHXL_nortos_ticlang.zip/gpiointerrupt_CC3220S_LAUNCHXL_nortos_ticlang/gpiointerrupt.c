/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */

// Mark Eilers
// 5-1 Milestone Three
// CS-350-R3340
// February 8, 2024

#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

// Include timer driver
#include <ti_drivers_config.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// Morse code message states
enum CURRENT_MESSAGES {SOS_MESSAGE, OK_MESSAGE} CURRENT_MESSAGE, BUTTON_STATE;

// LED code states
enum LED_STATES {LED_RED, LED_GREEN, LED_OFF} LED_STATE;

// Morse code messages
enum LED_STATES sosMessage[] = {
                                // S
                                LED_RED, LED_OFF,                                               // DOT, break
                                LED_RED, LED_OFF,                                               // DOT, break
                                LED_RED, LED_OFF, LED_OFF, LED_OFF,                             // DOT, character break

                                // O
                                LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,                       // DASH, break
                                LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,                       // Dash, break
                                LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF, LED_OFF, LED_OFF,     // Dash, character break

                                //S
                                LED_RED, LED_OFF,                                               // DOT, break
                                LED_RED, LED_OFF,                                               // DOT, break
                                LED_RED,                                                        // DOT, character break
                                LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF,  // Word break
};

enum LED_STATES okMessage[] = {
                               // O
                               LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,                        // DASH, break
                               LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,                        // DASH, break
                               LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF, LED_OFF, LED_OFF,      // DASH, character break

                               // K
                               LED_GREEN, LED_GREEN, LED_GREEN, LED_OFF,                        // DASH, break
                               LED_RED, LED_OFF,                                                // DOT, break
                               LED_GREEN, LED_GREEN, LED_GREEN,                                 // DASH, break
                               LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF, LED_OFF,   // Word break
};

// Message counter, initialized to 0.

/*
 *  ============== setMorseLEDs ==============
 * Function for the LEDs to represent a dot, dash, or break.
 */

void setMorseLEDs() {
    switch(LED_STATE) {
    case LED_RED: //DOT
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
        break;

    case LED_GREEN: //DASH
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
        break;

    case LED_OFF: //BREAK
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
        break;

    default:
        break;
    }
}
 /*
  * ============== timerCallback ==============
  * Callback function for the timer interrupt.
  */

void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    switch(CURRENT_MESSAGE) {
    case SOS_MESSAGE:
        LED_STATE = sosMessage[messageCounter];

        setMorseLEDs();
        messageCounter++; //Increment the message counter

        //If statement to check the message counter
        if(messageCounter == (sizeof(sosMessage)/sizeof(sosMessage[0]))) {

            //Set the current message to the button state
            CURRENT_MESSAGE = BUTTON_STATE;

            // messageCounter set = to 0
            messageCounter = 0;
        }
        break;

    case OK_MESSAGE:
        LED_STATE = okMessage [messageCounter];

        setMorseLEDs();
        messageCounter++; //Increment the message counter

        // If statement to check the message counter
        if(messageCounter == (sizeof(okMessage)/sizeof(okMessage[0]))) {

            //Set the current message to the button state
            CURRENT_MESSAGE = BUTTON_STATE;
            messageCOUNTER = 0;
        }
        break;

    default:
        break;
    }
}

/*
 * ============== timerINIT ===================
 * Initialization function for the timer interrupt on timer0.
 */
void initTimer(void) {
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    // if statement for it the timer is null
    if (timer0 == NULL) {
        //Fail to start the timer
        while (1) {}
    }

    // if statement if timer is null, status error.
    if(Timer_start(timer0) == Timer_STATUS_ERROR) {
        //Fail to start the timer
        while (1) {}
    }
}

/*
 * =============== gpioButtonCallback ==============
 * Callback function for the GPIO interrupt for either CONFIG_GPIO_BUTTON_0 or CONFIG_GPIO_BUTTON_1.
 */
void gpioButtonCallback(unit_least8_t index) {
    switch(BUTTON_STATE) {
        case SOS_MESSAGE:
            BUTTON_STATE = OK_MESSAGE;
            break;

        case OK_MESSAGE:
            BUTTON_STATE = SOS_MESSAGE;
            break;
        default:
            break;
    }
}

/*
 * ========== mainThread ================
 */
void *mainThread(void *arg0) {
    // Call driver init function for the GPIO and timer from above.
    GPIO_init();
    initTimer();

    // Make the configurations for the LED and button pins
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    // Start with the LED off
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    // Set the initial states to SOS message
    BUTTON_STATE = SOS_MESSAGE;
    CURRENT_MESSAGE = BUTTON_STATE;

    // Install button callback
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonCallback);

    // Enable interrupts to the system
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    // Interrupts will be enabled on CONFIG_GPIO_BUTTON1
    // if more than one input pin is available.
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {

        //Configure Button 1 pin
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        // Button callback
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonCallback);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    // Return statement
    return (NULL);
}
